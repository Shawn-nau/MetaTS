"""Package for time series forecasitng with Meta learning.
Release markers:
X.Y
X.Y.Z for bug fixes
"""

__version__ = "0.1.1"